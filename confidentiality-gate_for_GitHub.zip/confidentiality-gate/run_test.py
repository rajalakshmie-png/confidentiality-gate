import csv, time, json, hashlib
from detector import Detector, VARIANTS
from presidio_det import PresidioDetector
from data_test import TEST
from stats import wilson, boot_f1
assert hashlib.sha256(open('detector.py','rb').read()).hexdigest()==open('results/FROZEN_detector.sha256').read().split()[0], "detector changed after freeze!"
dets={k:Detector(**v) for k,v in VARIANTS.items()}
dets={"Presidio (default)":PresidioDetector(0.3), **dets}
rows=[]; summary={}
for name,d in dets.items():
    Y=[];P=[];lat=[]
    for y,cat,sub,q,r in TEST:
        t0=time.perf_counter(); s,sig=d.score(r,q); lat.append((time.perf_counter()-t0)*1000)
        p=d.predict(r,q); Y.append(y); P.append(p)
        rows.append(dict(detector=name,label=y,category=cat,subtype=sub,pred=p,score=s,signals=json.dumps([(a,b) for a,b,*_ in sig])))
    res={}
    for cat in ["direct","obfuscated-seen","obfuscated-unseen","semantic"]:
        ks=[p for y,c,_,_,_ ,p in [(t[0],t[1],t[2],t[3],t[4],pp) for t,pp in zip(TEST,P)] if c==cat]
        res[cat]=wilson(sum(ks),len(ks))
    struct=[pp for t,pp in zip(TEST,P) if t[0]==1 and t[1]!="semantic"]
    res["structured recall"]=wilson(sum(struct),len(struct))
    allleak=[pp for t,pp in zip(TEST,P) if t[0]==1]
    res["overall recall"]=wilson(sum(allleak),len(allleak))
    clean=[pp for t,pp in zip(TEST,P) if t[0]==0]
    res["false-block rate"]=wilson(sum(clean),len(clean))
    tp=sum(allleak); fp=sum(clean)
    res["precision"]=wilson(tp,tp+fp)
    res["F1"]=(2*tp/(2*tp+fp+(len(allleak)-tp)),)+boot_f1(Y,P)
    for sub in ["customer-owned","public","benign","plain"]:
        cs=[pp for t,pp in zip(TEST,P) if t[0]==0 and sub in t[2]]
        res[f"FB {sub}"]=wilson(sum(cs),len(cs))
    res["latency_ms_median"]=sorted(lat)[len(lat)//2]
    summary[name]=res
with open('results/test_predictions.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
json.dump(summary,open('results/test_summary.json','w'),indent=1)
for name,res in summary.items():
    print("==",name)
    for k,v in res.items():
        if isinstance(v,tuple): print(f"   {k:22s} {v[0]:.2f}  [{v[1]:.2f}, {v[2]:.2f}]")
        else: print(f"   {k:22s} {v:.2f}")
