# confidentiality-gate

Code, data, and raw results for the paper

> **Keeping Confidentiality Out of the LLM Judge: A Hardened Non-Generative Gate with Lifecycle Re-Screening for Customer-Support Guardrails**
> E. Rajalakshmi, Dayalin Leena G, Meenakshi D, Madhubala B — Rajalakshmi Engineering College, Chennai.
> RMK SMART 2026 (paper ID 26AIML413).

The gate screens every customer-support reply, and every self-refined rewrite of it, for structured confidential data (emails, phone, account, card and SSN-like numbers, ticket IDs, internal tool names, staff names) without any LLM call. Everything here runs on a CPU in a few minutes and needs no API key.

## Quick start

```bash
pip install -r requirements.txt
./run_all.sh
```

`run_all.sh` first checks that `detector.py` matches the hash frozen before any test data was written, then regenerates every table and figure. Outputs go to `results/` and `figs/`.

## Where each result in the paper comes from

| Paper item | Script | Result file |
|---|---|---|
| Pilot reproduction, Sec. VI-A | `run_pilot.py` | `results/log_pilot.txt` |
| τ calibration on D_dev, Sec. VI-A | `calibrate.py` | `results/dev_calibration.csv` |
| Table II, held-out D_test | `run_test.py` | `results/test_summary.json`, `results/test_predictions.csv` |
| Fig. 2, stress test D_stress; latency | `run_stress.py`, `make_figs.py` | `results/stress_results.csv`, `results/stress_latency_ms.json` |
| Table III, independent D_ind | `run_independent.py` | `results/independent_summary.json` |
| Generator-bias (transfer) check | `run_transfer.py` | `results/transfer_results.csv` |
| Table IV, allow-list injection D_inj | `run_injection.py` | `results/injection_summary.json` |
| Table V, re-screening D_gate | `run_gate.py` | `results/gate_simulation.json` |
| Record-based allow-list on D_test and D_gate | `run_record_regression.py` | `results/record_regression.json` |

## Files

| File | Contents |
|---|---|
| `detector.py` | The gate: normalization, regex, spaCy NER, severity scoring. **Frozen**; hash in `results/FROZEN_detector.sha256`. |
| `allowlist.py` | Record-based allow-list (added in revision; does not change detection). |
| `presidio_det.py` | Microsoft Presidio baseline (threshold 0.3, calibrated on D_dev). |
| `stats.py` | Wilson intervals, bootstrap F1. |
| `synth.py` | Seeded generator for D_stress and helpers for D_gate. |
| `data_pilot.py`, `data_dev.py`, `data_test.py` | Hand-written sets (30, 40, 56 cases). |
| `independent/` | Microsoft presidio-research `synth_dataset_v2.json` (1,500 sentences, MIT licence, commit 7f568b6). |
| `PROTOCOL.md` | Exact evaluation protocol, normalization rules, generator configuration. |

## Scope and limitations

The LLM review stages of the architecture (Review Agent, Error-Checking Assistant, Response Refiner) are not evaluated here. All data are English. D_pilot, D_dev and D_test were written by the authors with LLM drafting assistance; D_stress, D_gate and D_inj come from the authors' generators; only D_ind was written by third parties. See the paper's Section VII.

## Licence

Code and author-written data: MIT (see `LICENSE`). `independent/synth_dataset_v2.json` is © Presidio contributors, MIT licence (see `independent/LICENSE_presidio-research_MIT.txt`).
