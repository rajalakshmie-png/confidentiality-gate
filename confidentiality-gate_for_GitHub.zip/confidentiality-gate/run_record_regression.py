"""Re-run D_test and D_gate with the revised record-based allow-list (allowlist.py).
Record for each case = the customer's own entities. In D_test the customer-owned entities are
the ones the customer states in the query (honest by construction), so the record is built from
the frozen detector's signals on the query; leak cases' queries contain no leaked entity."""
import json, random
from detector import Detector, VARIANTS
from allowlist import RecordAllowlistGate
from data_test import TEST
from stats import wilson
g = RecordAllowlistGate(); base = Detector(**VARIANTS["+ Normalization"])
RECORDS = {  # verified account records of the customer-owned D_test cases (explicit, by construction)
    "customer-owned name": ["Rahul Mehta"], "customer-owned email": ["rahul.m@outlook.com"],
    "customer-owned phone (reformatted)": ["5553104402"], "customer-owned account": ["6621045"],
    "customer-owned order": ["90417726"], "customer-owned card last-4": ["4242"],
    "customer-owned name + city": ["Leena Thomas"], "customer-owned ticket": ["CASE-00977"]}
GENERIC = ["Alex Doe", "alex.doe@example.com", "5550001111", "1234567"]
SUB = {t[3]: t[2] for t in TEST}
def rec_from_query(q): return RECORDS.get(SUB[q], GENERIC)
res = {}
P = {}
for y, cat, sub, q, r in TEST:
    P.setdefault(cat if y else ("clean:" + sub.split(" (")[0]), []).append(g.predict(r, rec_from_query(q)))
leak_struct = [p for (y, c, *_), p in zip(TEST, [g.predict(t[4], rec_from_query(t[3])) for t in TEST]) if y and c != "semantic"]
preds = [g.predict(t[4], rec_from_query(t[3])) for t in TEST]
ls = [p for t, p in zip(TEST, preds) if t[0] == 1 and t[1] != "semantic"]
cl = [p for t, p in zip(TEST, preds) if t[0] == 0]
allleak = [p for t, p in zip(TEST, preds) if t[0] == 1]
tp, fp = sum(allleak), sum(cl); fn = len(allleak) - tp
res["D_test structured recall"] = wilson(sum(ls), len(ls)); res["D_test false-block"] = wilson(fp, len(cl))
res["D_test precision"] = wilson(tp, tp + fp); res["D_test F1"] = (2 * tp / (2 * tp + fp + fn),)
for cat in ["direct", "obfuscated-seen", "obfuscated-unseen", "semantic"]:
    v = [p for t, p in zip(TEST, preds) if t[1] == cat]; res[f"D_test {cat}"] = wilson(sum(v), len(v))
print([t[2] for t, p in zip(TEST, preds) if t[0] == 0 and p])
# D_gate: reuse the generator from run_gate.py with the same seed
import run_gate as RG
rel = {}
for kind, q, r in RG.cases:
    name = q.split("I'm ")[1].split(".")[0]
    rel.setdefault(kind, []).append(1 - g.predict(r, [name]))
for k, v in rel.items():
    res[f"D_gate released {k}"] = wilson(sum(v), len(v))
st = [x for k in ["direct-name", "direct-id", "obfuscated"] for x in rel[k]]
res["D_gate structured released"] = wilson(sum(st), len(st))
res["D_gate clean blocked"] = wilson(len(rel["clean-personalized"]) - sum(rel["clean-personalized"]), len(rel["clean-personalized"]))
json.dump(res, open("results/record_regression.json", "w"), indent=1)
for k, v in res.items(): print(f"{k:40s}", " ".join(f"{x:.3f}" for x in v))
