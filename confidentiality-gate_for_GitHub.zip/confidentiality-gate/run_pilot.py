from detector import Detector
from data_pilot import MAIN, ADV
orig = Detector(regex=True, ner=True)
match=0
print("MAIN")
for i,(y,t,psev) in enumerate(MAIN,1):
    s,sig = orig.score(t); p=int(s>=30)
    match += (s==psev)
    print(i,y,p,s,psev,"OK" if s==psev else "DIFF",[(a,b) for a,b,_ in sig])
print("severity match",match,"/20")
print("ADV")
tp=fn=fp=tn=0
for y,t,kind in ADV:
    s,sig=orig.score(t); p=int(s>=30)
    tp+=y&p; fn+=y&(1-p); fp+=(1-y)&p; tn+=(1-y)&(1-p)
    print(kind,y,p,s,[(a,b) for a,b,_ in sig])
print(tp,fn,fp,tn)
