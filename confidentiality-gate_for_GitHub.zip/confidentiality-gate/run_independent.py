"""Independent evaluation on Microsoft presidio-research synth_dataset_v2 (1,500 sentences,
written by third parties, not by the authors). Detector is the frozen detector.py.

Entity types the gate targets (in scope): PERSON, EMAIL_ADDRESS, PHONE_NUMBER, CREDIT_CARD,
US_SSN, IBAN_CODE, US_DRIVER_LICENSE.
Out-of-scope PII (no rule in the gate): STREET_ADDRESS, ZIP_CODE, IP_ADDRESS, DOMAIN_NAME, AGE.
Benign / non-confidential: GPE, ORGANIZATION, DATE_TIME, TITLE, NRP.

Metrics
  entity recall   : an in-scope entity counts as caught if a signal with severity >= tau
                    (or Presidio score >= thr) overlaps its text.
  false-block rate: fraction of sentences containing only benign entities (or none) that are blocked.
"""
import json, hashlib, re, unicodedata, csv, random
from collections import defaultdict
from detector import Detector, VARIANTS
from presidio_det import PresidioDetector
from stats import wilson

assert hashlib.sha256(open('detector.py', 'rb').read()).hexdigest() == \
    open('results/FROZEN_detector.sha256').read().split()[0], "detector changed after freeze!"

D = json.load(open('independent/synth_dataset_v2.json'))
IN = {"PERSON", "EMAIL_ADDRESS", "PHONE_NUMBER", "CREDIT_CARD", "US_SSN", "IBAN_CODE", "US_DRIVER_LICENSE"}
OUT = {"STREET_ADDRESS", "ZIP_CODE", "IP_ADDRESS", "DOMAIN_NAME", "AGE"}
BENIGN = {"GPE", "ORGANIZATION", "DATE_TIME", "TITLE", "NRP"}


def key(s):
    s = unicodedata.normalize("NFKC", s).lower()
    d = re.sub(r"\D", "", s)
    return d if len(d) >= 6 else re.sub(r"[^a-z0-9@.]", "", s)


def overlaps(sig, ent):
    a, b = key(sig), key(ent)
    if not a or not b:
        return False
    return a in b or b in a


dets = {"Presidio (default)": PresidioDetector(0.3), **{k: Detector(**v) for k, v in VARIANTS.items()}}
TAU = 30
ent_hits = defaultdict(lambda: defaultdict(list))
sent = defaultdict(lambda: defaultdict(list))
for name, d in dets.items():
    for row in D:
        text = row["full_text"]
        types = {s["entity_type"] for s in row["spans"]}
        score, sigs = d.score(text, "")
        blocked = d.predict(text, "")
        thr = d.thr if name.startswith("Presidio") else TAU
        strong = [s[1] for s in sigs if s[2] >= thr]
        for sp in row["spans"]:
            if sp["entity_type"] in IN:
                ent_hits[name][sp["entity_type"]].append(int(any(overlaps(x, sp["entity_value"]) for x in strong)))
        if types & IN:
            sent[name]["leak"].append(blocked)
        elif types & OUT:
            sent[name]["out-of-scope only"].append(blocked)
        else:
            sent[name]["benign/none"].append(blocked)

out = {}
for name in dets:
    r = {}
    allv = []
    for t in sorted(IN):
        v = ent_hits[name][t]; allv += v
        r[f"ent:{t}"] = (sum(v), len(v)) + wilson(sum(v), len(v))
    r["ent:ALL in-scope"] = (sum(allv), len(allv)) + wilson(sum(allv), len(allv))
    nonperson = [x for t in sorted(IN - {"PERSON"}) for x in ent_hits[name][t]]
    r["ent:structured IDs (non-PERSON)"] = (sum(nonperson), len(nonperson)) + wilson(sum(nonperson), len(nonperson))
    for g, v in sent[name].items():
        r[f"sent:{g}"] = (sum(v), len(v)) + wilson(sum(v), len(v))
    out[name] = r
json.dump(out, open('results/independent_summary.json', 'w'), indent=1)
for name, r in out.items():
    print("==", name)
    for k, v in r.items():
        print(f"   {k:34s} {v[0]:4d}/{v[1]:<4d} {v[2]:.2f} [{v[3]:.2f},{v[4]:.2f}]")
