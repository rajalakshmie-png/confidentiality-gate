# Evaluation protocol

This file states exactly how every number in the paper was produced. Code is the authority; line references are to the files in this repository.

## 1. Freeze procedure

1. Normalization rules and the threshold τ_conf were developed using **D_dev only** (`data_dev.py`, `dev_check.py`, `calibrate.py`).
2. τ_conf = 30 is the center of the full gate's accuracy plateau on D_dev (0.95 for τ from 15 to 45; `results/dev_calibration.csv`).
3. The SHA-256 of `detector.py` was then recorded in `results/FROZEN_detector.sha256` (2026-09-30T09:57:29Z), **before** `data_test.py`, `synth.py` or any other test set existed.
4. Every evaluation script asserts the hash before running. `detector.py` was not modified for the revision.
5. D_test was evaluated once. D_ind (independent) was obtained after the freeze and was never used to change any rule.
6. The revision added `allowlist.py` (record-based allow-list). It reuses the frozen detector's signals and normalization key and only changes which signals are dropped as customer-owned.

## 2. The gate (`detector.py`)

**Normalization** (`normalize`, `_digit_run_signals`), applied to a copy of the text; recognition runs on both the raw and normalized copies.
- Unicode NFKC; removal of zero-width characters (U+200B–U+200F, U+2060, U+FEFF, soft hyphen); Greek and Cyrillic look-alikes mapped to Latin (`CONFUSABLES`).
- Runs of four or more spelled digits ("five five five", "double seven", "triple nine", "oh") converted to digits.
- Whitespace inside digit/hyphen runs collapsed.
- Spelled or bracketed `at`/`dot` rewritten to `@`/`.` only when a spelled "dot", a bracketed at/dot, or a dotted local part is present.
- Digit runs of seven or more digits with `, . _ / -` or space separators reduced to bare digits and classified: 13–19 digits passing Luhn → card; 10 digits (or 11 starting with 1) → phone; 9 digits after "SSN"/"social" → SSN; otherwise only if a context word (account, card, SSN, routing, member id, PIN, IBAN, passport) precedes within 40 characters. Thousands-formatted numbers without such context are ignored.

**Recognition.** Regular expressions (`PATTERNS`) for SSN-like, card-like, account number, email, North-American phone, ticket ID (`[A-Z]{2,5}-\d{3,6}`), and internal tool names (Jira, Zendesk, Confluence, ServiceNow, SharePoint, internal wiki, admin panel, back-office); spaCy `en_core_web_sm` 3.8.0 entities PERSON, ORG, GPE.

**Scoring.** Severity per signal (`SEV`): SSN-like and card-like 95, account number and context-qualified long number 80, email 60, phone 55, internal tool 50, ticket ID and PERSON 45, ORG 20, GPE 10. A reply is blocked if the maximum severity ≥ 30.

## 3. Allow-list (`allowlist.py`)

- Sources: entities of the customer's verified account record, plus `PUBLIC_ALLOWLIST` in `detector.py`. Query text is never a source.
- A signal is dropped if its normalization key (`_key`: NFKC, lower case; digits only when ≥ 6 digits) equals or is contained in the key of one record entity. Keys shorter than 3 characters never match.
- In D_test, each customer-owned clean case has an explicit record (`RECORDS` in `run_record_regression.py`); all other cases use a generic unrelated profile. In D_gate the record is the customer's full name.
- The "query-derived" variant in Table IV is `Detector(..., allowlist=True)` called with the query text, i.e. the design in the original submission.

## 4. Datasets

| Set | Source | Generation |
|---|---|---|
| D_pilot (30) | `data_pilot.py` | Reconstructed from the pilot study's reported spans |
| D_dev (40) | `data_dev.py` | Hand-written |
| D_test (56) | `data_test.py` | Hand-written after the freeze |
| D_stress (5,400) | `synth.py` | `random.Random(2026)`; 6 identifier kinds × 16 operators (`OPS`), 100 per applicable pair = 4,700 leaks; 7 benign numeric templates × 100 = 700 |
| D_gate (1,000) | `run_gate.py` | `random.Random(7)`; 500 refinements adding a leak clause (staff name 20%, direct ID 20%, obfuscated ID 40%, semantic 20%); 500 greeting the customer by name |
| D_inj (1,000) | `run_injection.py` | `random.Random(413)`; 5 attack kinds × 100, 5 honest kinds × 100 |
| D_ind (1,500) | `independent/` | Microsoft presidio-research `data/synth_dataset_v2.json`, commit 7f568b6, unchanged |

## 5. Metrics

- **Recall** per leak class: fraction of leak cases blocked. **False-block rate**: fraction of clean cases blocked. **Precision, F1** over all D_test cases.
- **D_ind entity recall**: an in-scope entity (PERSON, EMAIL_ADDRESS, PHONE_NUMBER, CREDIT_CARD, US_SSN, IBAN_CODE, US_DRIVER_LICENSE) is caught if a signal with severity ≥ 30 (Presidio: score ≥ 0.3) overlaps its text after normalization keying. Sentence-level false blocks are measured on sentences whose labels contain only GPE, ORGANIZATION, DATE_TIME, TITLE, NRP, or nothing.
- **Transfer check**: operators of D_stress applied to D_ind card/email/phone spans that the gate catches unobfuscated, in sentences with no PERSON and no other blocking signal; cases where the operator leaves the value unchanged are excluded.
- **Intervals**: 95% Wilson for proportions; 95% bootstrap (1,000 resamples, seed 0) for F1.
- **Latency**: wall-clock per reply on one vCPU (Intel Xeon 2.1 GHz), median and 95th percentile over D_stress.

## 6. Environment used for the paper

Python 3.12, spaCy 3.8.16, en_core_web_sm 3.8.0, presidio-analyzer (latest at time of run), pandas, numpy, matplotlib. All accuracy results are deterministic given these versions and were verified by rerunning `run_all.sh` from a clean copy; wall-clock latency varies by machine and run (medians differ by about ±1 ms between runs on the same machine).
