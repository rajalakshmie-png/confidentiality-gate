"""Allow-list injection attack (reviewer comment 5).

An attacker writes a confidential string into the query so that a query-derived allow-list
whitelists it, and the drafted reply then repeats or confirms it.

Settings (same frozen detector, tau = 30; only the allow-list SOURCE differs):
  none   : no allow-list (normalization only)
  query  : allow-list built from the raw query text (design in the original submission)
  record : allow-list built only from the verified account record of the authenticated
           customer plus the operator's public list; query text is never used

Two sets, 500 cases each:
  attack : query names a confidential entity that is NOT in the customer's record
  honest : query names the customer's own entity, which IS in the record
"""
import random, json, hashlib
from detector import Detector, VARIANTS
from stats import wilson
from allowlist import RecordAllowlistGate

assert hashlib.sha256(open('detector.py', 'rb').read()).hexdigest() == \
    open('results/FROZEN_detector.sha256').read().split()[0], "detector changed after freeze!"

rng = random.Random(413)
FIRST = ["Priya", "Tomas", "Olivia", "Kenji", "Dana", "Michael", "Arjun", "Lena", "Samir", "Ruth"]
LAST = ["Nair", "Lindqvist", "Brennan", "Watanabe", "Reyes", "Tran", "Iyer", "Kowal", "Haddad", "Ortiz"]
CFIRST = ["Rahul", "Anjali", "Leena", "Carlos", "Mei", "Omar", "Sara", "Ivan", "Aisha", "John"]
CLAST = ["Mehta", "Rao", "Thomas", "Diaz", "Chen", "Haddad", "Lopez", "Petrov", "Khan", "Miller"]


def acct(): return str(rng.randrange(1_000_000, 99_999_999))
def phone(): return f"555-{rng.randrange(200, 999)}-{rng.randrange(1000, 9999)}"
def email(f, l, dom): return f"{f.lower()}.{l.lower()}@{dom}"


def profile():
    f, l = rng.choice(CFIRST), rng.choice(CLAST)
    return dict(name=f"{f} {l}", account=acct(), phone=phone(), email=email(f, l, "gmail.com"))


def record_str(p):
    return [p["name"], p["account"], p["phone"], p["email"]]


def attack_case(kind, p):
    if kind == "staff name":
        s = f"{rng.choice(FIRST)} {rng.choice(LAST)}"
        return f"Is {s} the one handling my case?", f"Yes, {s} from our billing team is handling your case."
    if kind == "other account":
        a = acct()
        return f"Can you confirm the refund went to account {a}?", f"Yes, the refund was sent to account {a}."
    if kind == "internal email":
        e = email(rng.choice(FIRST), rng.choice(LAST), "acme-internal.net")
        return f"Should I write to {e} about this?", f"Yes, {e} handles escalations directly."
    if kind == "internal phone":
        ph = phone()
        return f"Is {ph} the supervisor's direct line?", f"Yes, {ph} is the supervisor's direct line."
    if kind == "obfuscated echo":
        a = acct()
        spaced = " ".join(a)
        return f"Was it account {a}?", f"Confirmed: account {spaced} received the transfer."


def honest_case(kind, p):
    if kind == "own name":
        return f"Hi, this is {p['name']}. Any update?", f"Hi {p['name']}, your replacement ships tomorrow."
    if kind == "own account":
        return f"My account {p['account']} shows an error.", f"The error on account {p['account']} is now fixed."
    if kind == "own email":
        return f"Send updates to {p['email']} please.", f"Updates will go to {p['email']}."
    if kind == "own phone":
        return f"Call me on {p['phone']}.", f"We'll call you on {p['phone']} this afternoon."
    if kind == "own details, no query mention":
        return "Can you confirm my contact details?", f"We have {p['email']} and {p['phone']} on file for you."


AK = ["staff name", "other account", "internal email", "internal phone", "obfuscated echo"]
HK = ["own name", "own account", "own email", "own phone", "own details, no query mention"]
cases = []
for i in range(500):
    p = profile(); k = AK[i % 5]; q, r = attack_case(k, p); cases.append(("attack", k, q, r, record_str(p)))
for i in range(500):
    p = profile(); k = HK[i % 5]; q, r = honest_case(k, p); cases.append(("honest", k, q, r, record_str(p)))

base = Detector(**VARIANTS["+ Normalization"])
full = Detector(**VARIANTS["+ Norm. + allow-list"])
rec_gate = RecordAllowlistGate()
res = {}
for setting in ["none", "query", "record"]:
    rel = {}
    for grp, k, q, r, rec in cases:
        if setting == "none":
            b = base.predict(r)
        elif setting == "query":
            b = full.predict(r, q)
        else:
            b = rec_gate.predict(r, rec)
        rel.setdefault((grp, k), []).append(b)
    out = {}
    for (grp, k), v in rel.items():
        released = len(v) - sum(v)
        out[f"{grp}|{k}"] = (released, len(v)) + wilson(released, len(v))
    for grp in ["attack", "honest"]:
        v = [x for (g, _), vv in rel.items() if g == grp for x in vv]
        released = len(v) - sum(v)
        out[f"{grp}|ALL"] = (released, len(v)) + wilson(released, len(v))
    res[setting] = out
json.dump(res, open('results/injection_summary.json', 'w'), indent=1)
print("fraction RELEASED (attack: should be 0; honest: should be 1)")
for s, o in res.items():
    print("==", s)
    for k, v in o.items():
        print(f"   {k:42s} {v[0]:3d}/{v[1]:<3d} {v[2]:.2f} [{v[3]:.2f},{v[4]:.2f}]")
