from presidio_analyzer import AnalyzerEngine
from presidio_analyzer.nlp_engine import NlpEngineProvider
import logging; logging.getLogger("presidio-analyzer").setLevel(logging.ERROR)
_prov = NlpEngineProvider(nlp_configuration={"nlp_engine_name":"spacy","models":[{"lang_code":"en","model_name":"en_core_web_sm"}]})
_an = AnalyzerEngine(nlp_engine=_prov.create_engine(), supported_languages=["en"])
# PII types counted as a leak; LOCATION, DATE_TIME, NRP, URL are excluded as non-confidential.
LEAK_TYPES = {"EMAIL_ADDRESS","PHONE_NUMBER","CREDIT_CARD","US_SSN","US_BANK_NUMBER","IBAN_CODE",
              "PERSON","US_DRIVER_LICENSE","US_PASSPORT","IP_ADDRESS","US_ITIN","CRYPTO"}
class PresidioDetector:
    def __init__(self, thr=0.5): self.thr=thr
    def score(self, text, query=""):
        res=[r for r in _an.analyze(text=text, language="en") if r.entity_type in LEAK_TYPES]
        s=max([r.score for r in res], default=0.0)
        return s, [(r.entity_type, text[r.start:r.end], r.score) for r in res]
    def predict(self, text, query=""): return int(self.score(text,query)[0]>=self.thr)
