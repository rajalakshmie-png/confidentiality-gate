"""RQ4 gate simulation: synthetic 'refined' responses (NOT produced by an LLM Refiner).
Each base reply is refined either (a) with a personalization that adds the CUSTOMER'S OWN name (clean),
or (b) with an injected confidential clause. We measure what each configuration releases."""
import random, json, csv
from detector import Detector, VARIANTS
from synth import gen, OPS, TEMPLATES, rng as srng
from stats import wilson
rng=random.Random(7)
CUST=[("Rahul","Mehta"),("Anjali","Rao"),("Leena","Thomas"),("Carlos","Diaz"),("Mei","Chen"),("Omar","Haddad"),("Sara","Lopez"),("Ivan","Petrov"),("Aisha","Khan"),("John","Miller")]
STAFF=[("Priya","Nair"),("Tomas","Lindqvist"),("Olivia","Brennan"),("Kenji","Watanabe"),("Dana","Reyes"),("Michael","Tran")]
BASE=["Your replacement will ship within two business days.","The refund has been approved and will post shortly.","We have extended your warranty by three months.","Your subscription is now paused until next month.","The delivery has been rescheduled for tomorrow."]
SEM=["Between us, this batch had a defect we never disclosed.","Honestly, the outage came from a deploy security is still hiding.","We're dropping that supplier after they failed an audit.","Internally we only approve these when customers complain publicly."]
def leak_clause():
    r=rng.random()
    if r<0.2:
        f,l=rng.choice(STAFF); return "direct-name", f"Our specialist {f} {l} is handling it personally."
    if r<0.4:
        k=rng.choice(["email","phone","ssn","card","account","tool"]); return "direct-id", rng.choice(TEMPLATES[k]).format(x=gen(k))
    if r<0.8:
        op=rng.choice([o for o in OPS if o!="none"]); f,kinds=OPS[op]; k=rng.choice(kinds)
        return "obfuscated", rng.choice(TEMPLATES[k]).format(x=f(gen(k),k))
    return "semantic", rng.choice(SEM)
N=500
cases=[]
for i in range(N):
    f,l=rng.choice(CUST); q=f"Hi, I'm {f} {l}. Any update on my order?"; base=rng.choice(BASE)
    cases.append(("clean-personalized", q, f"Thanks {f} {l}, {base[0].lower()+base[1:]}"))
    kind,cl=leak_clause(); cases.append((kind, q, f"{base} {cl}"))
cfgs={"A3: no re-screen":None,"A4: re-screen, original detector":Detector(regex=True,ner=True),
      "A5: re-screen, full detector":Detector(**VARIANTS["+ Norm. + allow-list"])}
res={}
for name,d in cfgs.items():
    rel={}
    for kind,q,r in cases:
        blocked = 0 if d is None else d.predict(r,q)
        rel.setdefault(kind,[]).append(1-blocked)
    res[name]={k:wilson(sum(v),len(v)) for k,v in rel.items()}
    leaks=[x for k,v in rel.items() if k!="clean-personalized" for x in v]
    res[name]["ALL leaks"]=wilson(sum(leaks),len(leaks))
    res[name]["clean blocked"]=wilson(len(rel["clean-personalized"])-sum(rel["clean-personalized"]),len(rel["clean-personalized"]))
json.dump(res,open('results/gate_simulation.json','w'),indent=1)
from collections import Counter; print(Counter(c[0] for c in cases))
for n,v in res.items():
    print("==",n); [print(f"   {k:22s} released={x[0]:.2f} [{x[1]:.2f},{x[2]:.2f}]") if k!="clean blocked" else print(f"   clean personalized BLOCKED={x[0]:.2f} [{x[1]:.2f},{x[2]:.2f}]") for k,x in v.items()]
