import json, csv, os
os.makedirs("figs", exist_ok=True)
import numpy as np, pandas as pd
import matplotlib
clip=lambda a: np.maximum(0, np.array(a, dtype=float))
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

plt.rcParams.update({"font.family": "serif", "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8,
                     "legend.fontsize": 7, "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.bbox": "tight", "savefig.dpi": 300})
COL = {"Presidio (default)": "#9e9e9e", "Regex only": "#9ecae1", "Regex + NER (original)": "#3182bd",
       "+ Normalization": "#e6550d", "+ Norm. + allow-list": "#31a354"}
SHORT = {"Presidio (default)": "Presidio", "Regex only": "Regex", "Regex + NER (original)": "Regex+NER (orig.)",
         "+ Normalization": "+Norm.", "+ Norm. + allow-list": "+Norm.+Allow (full)"}
S = json.load(open("results/test_summary.json"))
DETS = list(S.keys())


def save(fig, name):
    fig.savefig(f"figs/{name}.pdf"); fig.savefig(f"figs/{name}.png"); plt.close(fig)


# ---- Fig 2: held-out recall by leak class
cats = [("direct", "Direct\n(n=8)"), ("obfuscated-seen", "Obfusc. seen\n(n=6)"),
        ("obfuscated-unseen", "Obfusc. unseen\n(n=10)"), ("semantic", "Semantic\n(n=6)")]
fig, ax = plt.subplots(figsize=(7.0, 2.4))
w = 0.16; x = np.arange(len(cats))
for i, d in enumerate(DETS):
    p = [S[d][c][0] for c, _ in cats]; lo = [S[d][c][0] - S[d][c][1] for c, _ in cats]; hi = [S[d][c][2] - S[d][c][0] for c, _ in cats]
    ax.bar(x + (i - 2) * w, p, w, color=COL[d], label=SHORT[d], yerr=[clip(lo), clip(hi)], capsize=1.5, error_kw={"lw": 0.6})
ax.set_xticks(x, [l for _, l in cats]); ax.set_ylabel("Recall (95% Wilson CI)"); ax.set_ylim(0, 1.08)
ax.legend(ncol=5, loc="upper center", bbox_to_anchor=(0.5, 1.2), frameon=False)
save(fig, "fig2_heldout_recall_by_class")

# ---- Fig 3: safety-usability trade-off
fig, ax = plt.subplots(figsize=(3.45, 2.6))
for d in DETS:
    fb = S[d]["false-block rate"]; rc = S[d]["structured recall"]
    ax.errorbar(fb[0], rc[0], xerr=clip([[fb[0] - fb[1]], [fb[2] - fb[0]]]), yerr=clip([[rc[0] - rc[1]], [rc[2] - rc[0]]]),
                fmt="o", color=COL[d], ms=5, capsize=2, lw=0.7, label=SHORT[d])
ax.set_xlabel("False-block rate on clean responses (n=26)"); ax.set_ylabel("Structured-leak recall (n=24)")
ax.set_xlim(-0.03, 0.65); ax.set_ylim(0, 1.02)
ax.annotate("ideal", xy=(0, 1), xytext=(0.08, 0.95), fontsize=7, arrowprops=dict(arrowstyle="->", lw=0.6))
OFF = {"Presidio (default)": (0.01, -0.11), "Regex only": (-0.02, -0.14), "Regex + NER (original)": (0.02, 0.04),
       "+ Normalization": (0.02, 0.04), "+ Norm. + allow-list": (0.02, -0.12)}
for d in DETS:
    fb = S[d]["false-block rate"][0]; rc = S[d]["structured recall"][0]; dx, dy = OFF[d]
    ax.text(fb + dx, rc + dy, SHORT[d], fontsize=6.8, color=COL[d] if d != "Regex only" else "#4a90b8")
save(fig, "fig3_tradeoff")

# ---- Fig 4: stress-test heatmap
df = pd.read_csv("results/stress_results.csv")
rec = df[(df.type == "recall") & (~df.group.str.startswith("kind:")) & (df.group != "ALL")]
order = ["Presidio (default)", "Regex only", "Regex + NER (original)", "+ Normalization"]
piv = rec.pivot(index="group", columns="detector", values="p")[order]
piv = piv.loc[piv["+ Normalization"].sort_values(ascending=False).index]
nmap = rec.groupby("group").n.first()
fig, ax = plt.subplots(figsize=(3.45, 3.9))
im = ax.imshow(piv.values, cmap="RdYlGn", vmin=0, vmax=1, aspect="auto")
ax.set_xticks(range(len(order)), ["Presidio", "Regex", "Regex+NER\n(orig.)", "+Norm.\n(full)"])
ax.set_yticks(range(len(piv)), [f"{g} (n={nmap[g]})" for g in piv.index])
for i in range(piv.shape[0]):
    for j in range(piv.shape[1]):
        v = piv.values[i, j]; ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=6.3, color="black" if 0.25 < v < 0.8 else "white")
cb = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02); cb.set_label("Recall")
ax.spines[:].set_visible(False)
save(fig, "fig4_stress_heatmap")

# ---- Fig 5: calibration on dev
cal = pd.read_csv("results/dev_calibration.csv")
fig, ax = plt.subplots(figsize=(3.45, 2.2))
for d in ["Regex + NER (original)", "+ Norm. + allow-list"]:
    s = cal[cal.variant == d]; ax.plot(s.tau, s.acc, marker="o", ms=2.5, lw=1, color=COL[d], label=SHORT[d])
ax.axvspan(15, 45, color="#31a354", alpha=0.08, lw=0); ax.axvline(30, color="k", lw=0.7, ls="--")
ax.text(31, 0.47, "τ = 30", fontsize=7); ax.text(16, 0.99, "plateau (full)", fontsize=6.5, color="#31a354")
ax.set_xlabel("Threshold τ_conf"); ax.set_ylabel("Accuracy on D_conf-dev (n=40)"); ax.set_ylim(0.45, 1.02)
ax.legend(loc="upper right", frameon=False)
save(fig, "fig5_threshold_calibration")

# ---- Fig 6: gate simulation
G = json.load(open("results/gate_simulation.json"))
cfg = list(G.keys()); groups = [("direct-name", "Staff name"), ("direct-id", "Direct ID"), ("obfuscated", "Obfuscated"),
                                ("semantic", "Semantic"), ("ALL leaks", "All leaks")]
gc = ["#bdbdbd", "#3182bd", "#31a354"]
fig, (a1, a2) = plt.subplots(1, 2, figsize=(7.0, 2.3), gridspec_kw={"width_ratios": [4, 1.3]})
x = np.arange(len(groups)); w = 0.26
for i, c in enumerate(cfg):
    v = [G[c][g][0] for g, _ in groups]; e = [[G[c][g][0] - G[c][g][1] for g, _ in groups], [G[c][g][2] - G[c][g][0] for g, _ in groups]]
    a1.bar(x + (i - 1) * w, v, w, color=gc[i], yerr=clip(e), capsize=1.5, error_kw={"lw": 0.6}, label=c)
NS = {"direct-name": 101, "direct-id": 122, "obfuscated": 189, "semantic": 88, "ALL leaks": 500}
a1.set_xticks(x, [f"{l}\n(n={NS[g]})" for g, l in groups]); a1.set_ylabel("Fraction of leaks released"); a1.set_ylim(0, 1.1)
h, lb = a1.get_legend_handles_labels()
fig.legend(h, lb, frameon=False, loc="lower center", bbox_to_anchor=(0.5, -0.2), ncol=3)
v = [G[c]["clean blocked"][0] for c in cfg]
a2.bar(range(3), v, color=gc); a2.set_xticks(range(3), ["A3", "A4", "A5"]); a2.set_ylim(0, 1.1)
a2.set_title("Clean personalized refinements\nblocked (n=500)", fontsize=7.5)
for i, t in enumerate(v): a2.text(i, t + 0.02, f"{t:.2f}", ha="center", fontsize=7)
save(fig, "fig6_gate_simulation")

# ---- Fig 7: clean false-block by subgroup
subs = [("FB plain", "Plain\n(n=8)"), ("FB benign", "Benign\nentities\n(n=6)"), ("FB customer-owned", "Customer-\nowned\n(n=8)"), ("FB public", "Public\ncontacts\n(n=3)")]
fig, ax = plt.subplots(figsize=(3.45, 2.2))
x = np.arange(len(subs)); w = 0.25
for i, d in enumerate(["Presidio (default)", "Regex + NER (original)", "+ Norm. + allow-list"]):
    p = [S[d][s][0] for s, _ in subs]
    ax.bar(x + (i - 1) * w, p, w, color=COL[d], label=SHORT[d])
    for xi, v in zip(x + (i - 1) * w, p): ax.text(xi, v + 0.02, f"{v:.2f}", ha="center", fontsize=5.5, rotation=90)
ax.set_xticks(x, [l for _, l in subs]); ax.set_ylabel("False-block rate"); ax.set_ylim(0, 1.25)
ax.legend(frameon=False, loc="upper left")
save(fig, "fig7_false_blocks_by_subgroup")

# ---- Fig 8: latency
L = json.load(open("results/stress_latency_ms.json"))
fig, ax = plt.subplots(figsize=(3.45, 2.0))
keys = ["Regex only", "Regex + NER (original)", "+ Normalization", "Presidio (default)"]
bp = ax.boxplot([L[k] for k in keys], vert=False, showfliers=False, patch_artist=True, widths=0.55)
for patch, k in zip(bp["boxes"], keys): patch.set_facecolor(COL[k])
ax.set_yticks(range(1, 5), [SHORT[k] for k in keys]); ax.set_xscale("log")
ax.set_xlabel("Latency per response (ms, log scale; n = 4,700)")
save(fig, "fig8_latency")
print("done")
