#!/usr/bin/env bash
# Reproduces every number, table and figure in the paper. CPU only, no API keys.
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c <(head -1 results/FROZEN_detector.sha256)   # detector must match the frozen hash
python run_pilot.py               > results/log_pilot.txt              # reproduction of the pilot (Sec. VI-A)
python calibrate.py                                                     # tau sweep on D_dev -> results/dev_calibration.csv
python run_test.py                > results/log_test.txt               # Table II  (held-out D_test)
python run_stress.py              > results/log_stress.txt             # Fig. 2    (D_stress)
python run_independent.py         > results/log_independent.txt        # Table III (independent D_ind)
python run_transfer.py            > results/log_transfer.txt           # generator-bias check (Sec. VI-A)
python run_injection.py           > results/log_injection.txt          # Table IV  (D_inj)
python run_gate.py                > results/log_gate.txt               # Table V   (D_gate)
python run_record_regression.py   > results/log_record_regression.txt  # record-based allow-list on D_test, D_gate
python make_figs.py                                                     # figures -> figs/
echo "Done. Compare results/*.json with the paper's tables."
