import math, random
def wilson(k,n,z=1.96):
    if n==0: return (float('nan'),)*3
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return p, max(0,c-h), min(1,c+h)
def boot_f1(y,p,B=1000,seed=0):
    rng=random.Random(seed); n=len(y); vals=[]
    for _ in range(B):
        idx=[rng.randrange(n) for _ in range(n)]
        tp=sum(1 for i in idx if y[i] and p[i]); fp=sum(1 for i in idx if not y[i] and p[i]); fn=sum(1 for i in idx if y[i] and not p[i])
        vals.append(2*tp/(2*tp+fp+fn) if tp else 0.0)
    vals.sort(); return vals[int(.025*B)], vals[int(.975*B)]
