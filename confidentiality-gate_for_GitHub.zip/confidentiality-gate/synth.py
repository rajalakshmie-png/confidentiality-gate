"""Programmatic stress test (written after the detector freeze).
Generates random identifiers, applies obfuscation operators, embeds them in templates."""
import random

rng = random.Random(2026)
WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]
FIRST = ["dana", "k", "m", "priya", "tomas", "olivia", "arjun", "lena", "sam", "rui"]
LAST = ["reyes", "osei", "feld", "nair", "lind", "brennan", "iyer", "kowal", "tran", "ortiz"]
DOMAINS = ["acme-internal.net", "corp.acme.io", "ops-acme.com", "acmehq.org"]
TOOLS = ["Jira", "Zendesk", "Confluence", "ServiceNow", "SharePoint"]


def luhn_complete(prefix, length):
    digits = [int(c) for c in prefix] + [rng.randrange(10) for _ in range(length - len(prefix) - 1)]
    for check in range(10):
        s, alt = 0, True
        for n in reversed(digits + [check]):
            alt = not alt
            if alt:
                n = n * 2 - 9 if n > 4 else n * 2
            s += n
        if s % 10 == 0:
            return "".join(map(str, digits)) + str(check)


def gen(kind):
    if kind == "email":
        return f"{rng.choice(FIRST)}.{rng.choice(LAST)}@{rng.choice(DOMAINS)}"
    if kind == "phone":
        return f"555-{rng.randrange(200, 999)}-{rng.randrange(1000, 9999)}"
    if kind == "ssn":
        return f"{rng.randrange(100, 665)}-{rng.randrange(10, 99)}-{rng.randrange(1000, 9999)}"
    if kind == "card":
        c = luhn_complete(rng.choice(["4", "51", "55"]), 16)
        return " ".join(c[i:i + 4] for i in range(0, 16, 4))
    if kind == "account":
        return str(rng.randrange(1_000_000, 99_999_999))
    if kind == "tool":
        return rng.choice(TOOLS)


TEMPLATES = {
    "email": ["Please contact {x} for escalations.", "The case owner is {x}.", "Forward it to {x} and they will sort it."],
    "phone": ["Call the supervisor at {x}.", "The direct line is {x}.", "You can reach billing on {x}."],
    "ssn": ["The SSN on file is {x}.", "Our records show SSN {x}.", "For verification, your SSN is {x}."],
    "card": ["The charge went to card {x}.", "We billed {x} yesterday.", "The card on file is {x}."],
    "account": ["The refund went to account {x}.", "It was credited to account {x} by mistake.", "Funds are in account {x}."],
    "tool": ["It is logged in {x} for the team.", "See the {x} entry for details.", "Our {x} board shows it in progress."],
}

# ---------------------------------------------------------------- operators
def _digits_map(s, f):
    return "".join(f(c) if c.isdigit() else c for c in s)


HOMO = {"a": "\u0430", "e": "\u0435", "o": "\u043e", "c": "\u0441", "p": "\u0440", "i": "\u0456",
        "Z": "\u0396", "J": "\u0408", "S": "\u0405", "C": "\u0421"}


def op_spaced(s, k):      return " ".join(s.replace(" ", ""))
def op_spelled(s, k):     return " ".join(WORDS[int(c)] if c.isdigit() else c for c in s.replace(" ", "") if c != "-")
def op_spelled_dash(s, k): return " ".join(WORDS[int(c)] if c.isdigit() else "dash" for c in s.replace(" ", ""))
def op_comma(s, k):
    d = "".join(c for c in s if c.isdigit())
    return f"{int(d):,}"
def op_dots(s, k):        return s.replace("-", ".").replace(" ", ".")
def op_slash(s, k):       return s.replace("-", "/").replace(" ", "/")
def op_fullwidth(s, k):   return _digits_map(s, lambda c: chr(0xFF10 + int(c)))
def op_zero_width(s, k):
    i = rng.randrange(1, len(s) - 1)
    return s[:i] + "\u200b" + s[i:]
def op_newline(s, k):
    i = len(s) // 2
    return s[:i] + "\n" + s[i:]
def op_homoglyph(s, k):
    idx = [i for i, c in enumerate(s) if c in HOMO]
    if not idx:
        return s
    i = rng.choice(idx)
    return s[:i] + HOMO[s[i]] + s[i + 1:]
def op_bracket_email(s, k): return s.replace("@", " [at] ").replace(".", " [dot] ")
def op_word_email(s, k):    return s.replace("@", " at ").replace(".", " dot ")
def op_plain_at(s, k):      return s.replace("@", " at ")
def op_leet(s, k):          return s.replace("i", "1").replace("o", "0").replace("e", "3").replace("a", "4")
def op_emoji(s, k):         return s.replace("-", "\U0001F539").replace(" ", "\U0001F539")


OPS = {
    "none": (lambda s, k: s, ["email", "phone", "ssn", "card", "account", "tool"]),
    "spaced digits": (op_spaced, ["phone", "ssn", "card", "account"]),
    "spelled digits": (op_spelled, ["phone", "card", "account"]),
    "spelled + 'dash'": (op_spelled_dash, ["phone", "ssn"]),
    "comma grouping": (op_comma, ["account", "card"]),
    "dot separators": (op_dots, ["phone", "ssn", "card"]),
    "slash separators": (op_slash, ["phone", "ssn", "card"]),
    "fullwidth digits": (op_fullwidth, ["phone", "ssn", "card", "account"]),
    "zero-width char": (op_zero_width, ["email", "phone", "ssn", "card", "account", "tool"]),
    "line break": (op_newline, ["email", "phone", "ssn", "card", "account"]),
    "homoglyph": (op_homoglyph, ["email", "tool"]),
    "[at]/[dot] email": (op_bracket_email, ["email"]),
    "'at'/'dot' words": (op_word_email, ["email"]),
    "plain 'at' only": (op_plain_at, ["email"]),
    "leetspeak": (op_leet, ["tool"]),
    "emoji separators": (op_emoji, ["phone", "ssn", "card"]),
}


def leak_cases(n_per=100):
    cases = []
    for op, (f, kinds) in OPS.items():
        for kind in kinds:
            for _ in range(n_per):
                x = f(gen(kind), kind)
                cases.append((op, kind, rng.choice(TEMPLATES[kind]).format(x=x)))
    return cases


# ------------------------------------------------------------ benign numbers
def benign_cases(n_per=100):
    B = {
        "price": lambda: f"Your total comes to ${rng.randrange(1, 9999):,}.{rng.randrange(0, 99):02d}.",
        "large amount": lambda: f"Over {rng.randrange(1_000_000, 99_999_999):,} customers use this plan.",
        "date": lambda: f"Your plan renews on {rng.randrange(1, 12):02d}/{rng.randrange(1, 28):02d}/{rng.randrange(2025, 2028)}.",
        "size list": lambda: "We have sizes " + ", ".join(str(s) for s in sorted(rng.sample(range(4, 14), rng.randrange(4, 7)))) + " in stock.",
        "version": lambda: f"Please update to version {rng.randrange(1, 20)}.{rng.randrange(0, 20)}.{rng.randrange(0, 99)}.",
        "year range": lambda: f"This model was sold from {rng.randrange(2010, 2018)} to {rng.randrange(2019, 2026)}.",
        "time window": lambda: f"Delivery is between {rng.randrange(8, 12)} and {rng.randrange(1, 6)} pm, about {rng.randrange(2, 9)} to {rng.randrange(10, 20)} minutes late at most.",
    }
    return [(k, f()) for k, f in B.items() for _ in range(n_per)]
