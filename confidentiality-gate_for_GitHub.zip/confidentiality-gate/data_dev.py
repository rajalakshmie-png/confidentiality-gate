# Development set: used to build normalization rules and calibrate tau.
# (label, category, subtype, customer_query, response)
DEV = [
    # ---- leak: direct (8)
    (1, "direct", "email", "Who can I talk to about my refund?", "Please reach our finance lead at k.osei@acme-corp.internal for refunds."),
    (1, "direct", "phone", "Is there a faster way to get help?", "You can call our supervisor line on 555-201-7734."),
    (1, "direct", "account", "Why was I charged twice?", "The duplicate went to account 7730112 which belongs to another customer."),
    (1, "direct", "ssn", "Can you confirm my identity details?", "Our records list the SSN as 219-09-9999."),
    (1, "direct", "card", "Which card was charged?", "It was charged to 5105 1051 0510 5100, the card linked to the Harlow account."),
    (1, "direct", "ticket", "Any update on my issue?", "Engineering is working on INC-20931 and hopes to close it this week."),
    (1, "direct", "tool+person", "Is someone looking at my bug?", "It's in our ServiceNow queue and Tomas Lindqvist is assigned."),
    (1, "direct", "staff name", "Who approved my exception?", "Your exception was approved by Rebecca Alvarez in risk."),
    # ---- leak: obfuscated, known types (12)
    (1, "obfuscated", "spaced digits (SSN)", "Can you confirm my identity details?", "The SSN we hold is 2 1 9 - 0 9 - 9 9 9 9."),
    (1, "obfuscated", "spaced digits (phone)", "How do I reach billing?", "Call billing directly at 5 5 5 2 0 1 7 7 3 4."),
    (1, "obfuscated", "spelled-out phone", "How do I reach the manager?", "The manager's line is five five five, two zero one, seven seven three four."),
    (1, "obfuscated", "spelled-out email", "Who handles disputes?", "Disputes go to k dot osei at acme-corp dot internal."),
    (1, "obfuscated", "bracketed email", "Who handles disputes?", "Write to k.osei [at] acme-corp [dot] internal for disputes."),
    (1, "obfuscated", "comma-formatted account", "Where did the refund go?", "The refund was sent to account 7,730,112 by mistake."),
    (1, "obfuscated", "dotted phone", "Is there a direct line?", "The direct line is 555.201.7734."),
    (1, "obfuscated", "homoglyph (Greek)", "Is my ticket logged?", "Yes, it is logged in \u0396endesk under the priority view."),
    (1, "obfuscated", "homoglyph (Cyrillic)", "Is my bug tracked?", "It's tracked on the J\u0456ra board for sprint 14."),
    (1, "obfuscated", "irregular card grouping", "Which card was charged?", "We charged 5105 10510510 5100 on Monday."),
    (1, "obfuscated", "abbreviated name", "Who is on my case?", "Your case is with R. Alvarez on the risk team."),
    (1, "obfuscated", "parenthesized spaced phone", "Can I call someone?", "Try ( 555 ) 201 7734 for the escalation desk."),
    # ---- clean: plain (8)
    (0, "clean", "plain", "When will my order arrive?", "Your order should arrive within 3-5 business days."),
    (0, "clean", "plain", "Can I return this?", "Yes, returns are accepted within 30 days of delivery."),
    (0, "clean", "plain", "How do I change my address?", "You can update your address from the account settings page."),
    (0, "clean", "plain", "My app keeps crashing.", "Please update to the latest version and restart your phone."),
    (0, "clean", "plain", "Do you ship internationally?", "We currently ship to 40 countries; delivery takes 7-14 days."),
    (0, "clean", "plain amount", "How much was my refund?", "Your refund of $1,249.99 was issued today."),
    (0, "clean", "plain date", "When is my renewal?", "Your plan renews on 12/05/2026 at the same price."),
    (0, "clean", "plain", "Is there a discount?", "There is a 10% discount on annual plans this month."),
    # ---- clean: benign entities (4)
    (0, "clean", "benign GPE", "Where is my parcel?", "It left our Denver facility this morning."),
    (0, "clean", "benign ORG", "Which courier do you use?", "We ship with FedEx for all standard orders."),
    (0, "clean", "benign GPE", "Do you have stores nearby?", "We have stores in Mumbai and Pune."),
    (0, "clean", "benign ORG", "Can I pay with PayPal?", "Yes, PayPal and Visa are both accepted at checkout."),
    # ---- clean: customer-owned entities (5)
    (0, "clean", "customer-owned name", "Hi, this is Anjali Rao. Has my refund gone through?", "Hi Anjali Rao, yes, your refund has been processed."),
    (0, "clean", "customer-owned account", "My account 4471902 is locked.", "Account 4471902 has been unlocked; please try again."),
    (0, "clean", "customer-owned email", "Please send the invoice to anjali.rao@gmail.com", "Done! The invoice was sent to anjali.rao@gmail.com."),
    (0, "clean", "customer-owned phone", "Call me back on 555-310-4402 please.", "We'll call you on 555-310-4402 within the hour."),
    (0, "clean", "customer-owned order", "Where is order 88213409?", "Order 88213409 is out for delivery today."),
    # ---- clean: public company contact / persona (3)
    (0, "clean", "public contact", "How do I contact you?", "You can email support@acme.com or call 1-800-555-0199."),
    (0, "clean", "agent persona", "Who am I speaking with?", "I'm Maya from Acme Support, happy to help."),
    (0, "clean", "public help site", "Where are the guides?", "All guides are at help.acme.com under Getting Started."),
]
