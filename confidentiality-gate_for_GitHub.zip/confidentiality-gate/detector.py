"""Non-generative confidential detector.

Layers (each can be switched on/off for ablation):
  regex      structured-identifier patterns (original design)
  ner        spaCy en_core_web_sm PERSON / ORG / GPE (original design)
  normalize  text normalization before recognition (new)
  allowlist  drop signals that match customer-owned or public entities (new)
"""
import re, unicodedata, time
import spacy

_NLP = spacy.load("en_core_web_sm")

SEV = {"ssn_like": 95, "credit_card_like": 95, "account_number": 80, "email": 60,
       "phone": 55, "internal_tool_ref": 50, "ticket_id": 45, "long_number_ctx": 80,
       "NER:PERSON": 45, "NER:ORG": 20, "NER:GPE": 10}

# ---------------------------------------------------------------- regex layer
PATTERNS = [
    ("ssn_like",         re.compile(r"(?<!\d)\d{3}-\d{2}-\d{4}(?!\d)")),
    ("credit_card_like", re.compile(r"(?<!\d)(?:\d{4}[ -]?){3}\d{4}(?!\d)")),
    ("account_number",   re.compile(r"\b(?:account|acct|a/c)\s*(?:number|no\.?|#)?\s*[:#]?\s*\d{6,}", re.I)),
    ("email",            re.compile(r"\b[\w.+-]+@[\w-]+(?:\.[\w-]+)+\b")),
    ("phone",            re.compile(r"(?<![\d-])(?:\+?1[ .-]?)?\(?\d{3}\)?[ .-]?\d{3}[ .-]?\d{4}(?![\d-])")),
    ("ticket_id",        re.compile(r"\b[A-Z]{2,5}-\d{3,6}\b")),
    ("internal_tool_ref", re.compile(r"\b(?:jira|zendesk|confluence|servicenow|sharepoint|"
                                     r"internal wiki|admin panel|back-?office)\b", re.I)),
]

# ------------------------------------------------------------ normalization
ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u200e\u200f\u2060\ufeff\u00ad"), None)
CONFUSABLES = str.maketrans({
    # Greek
    "Α": "A", "Β": "B", "Ε": "E", "Ζ": "Z", "Η": "H", "Ι": "I", "Κ": "K", "Μ": "M", "Ν": "N",
    "Ο": "O", "Ρ": "P", "Τ": "T", "Υ": "Y", "Χ": "X", "ο": "o", "ν": "v", "α": "a", "ι": "i",
    # Cyrillic
    "А": "A", "В": "B", "Е": "E", "К": "K", "М": "M", "Н": "H", "О": "O", "Р": "P", "С": "C",
    "Т": "T", "Х": "X", "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "у": "y", "х": "x",
    "і": "i", "ј": "j", "ѕ": "s",
})
DIGIT_WORDS = {"zero": "0", "oh": "0", "one": "1", "two": "2", "three": "3", "four": "4",
               "five": "5", "six": "6", "seven": "7", "eight": "8", "nine": "9"}
_DW = "|".join(DIGIT_WORDS)
_TOKEN = rf"(?:\d|{_DW}|double\s+(?:\d|{_DW})|triple\s+(?:\d|{_DW}))"
_SPELLED_RUN = re.compile(rf"\b{_TOKEN}(?:[\s,\-]+{_TOKEN}){{3,}}\b", re.I)


def _spell_to_digits(m):
    toks = re.findall(rf"double\s+\w+|triple\s+\w+|\d|{_DW}|-", m.group(0), re.I)
    out = []
    for t in toks:
        tl = t.lower()
        if tl == "-":
            out.append("-")
        elif tl.startswith(("double", "triple")):
            d = tl.split()[1]
            out.append((DIGIT_WORDS.get(d, d)) * (2 if tl.startswith("double") else 3))
        else:
            out.append(DIGIT_WORDS.get(tl, tl))
    s = "".join(out)
    return re.sub(r"-+", "-", s).strip("-")


_EMAIL_WORDY = re.compile(
    r"\b([\w+-]+(?:\s*(?:\.|\bdot\b|[\[\(]dot[\]\)])\s*[\w+-]+)*)\s*(?:@|\bat\b|[\[\(]\s*at\s*[\]\)])\s*"
    r"([\w-]+(?:\s*(?:\.|\bdot\b|[\[\(]\s*dot\s*[\]\)])\s*[\w-]+)+)", re.I)


def _email_fix(m):
    whole = m.group(0)
    # only rewrite when there is a clear obfuscation signal: a spelled "dot",
    # a bracketed at/dot, or a dotted local part ("k.osei at ...").
    if not (re.search(r"\bdot\b|[\[\(]\s*(?:at|dot)\s*[\]\)]", whole, re.I)
            or re.search(r"[.]", m.group(1))):
        return whole
    dot = lambda s: re.sub(r"\s*(?:\.|\bdot\b|[\[\(]\s*dot\s*[\]\)])\s*", ".", s, flags=re.I)
    return f"{dot(m.group(1))}@{dot(m.group(2))}"


def normalize(text):
    t = unicodedata.normalize("NFKC", text).translate(ZERO_WIDTH).translate(CONFUSABLES)
    t = _SPELLED_RUN.sub(_spell_to_digits, t)
    # collapse whitespace inside digit/hyphen runs: "1 2 3 - 4 5" -> "123-45"
    t = re.sub(r"(?<=[\d-])[ \t\n]+(?=[\d-])", "", t)
    t = re.sub(r"\(\s*(\d{3})\s*\)", r"(\1)", t)
    t = _EMAIL_WORDY.sub(_email_fix, t)
    return t


_DIGIT_RUN = re.compile(r"(?<![\w.])\d(?:[\d,._/ -]?\d){6,}(?![\w])")
_CTX = re.compile(r"(account|acct|card|ssn|social security|routing|member id|pin|iban|passport)", re.I)


def _digit_run_signals(t):
    """Strip separators inside long digit runs and classify by length + context."""
    sigs = []
    for m in _DIGIT_RUN.finditer(t):
        raw = m.group(0)
        d = re.sub(r"\D", "", raw)
        ctx = t[max(0, m.start() - 40):m.start()]
        if re.fullmatch(r"\d{1,3}(,\d{3})+(\.\d+)?", raw):   # thousands-formatted amount
            if not _CTX.search(ctx):
                continue
        if 13 <= len(d) <= 19 and _luhn(d):
            sigs.append(("credit_card_like", raw))
        elif len(d) == 10 or (len(d) == 11 and d[0] == "1"):
            sigs.append(("phone", raw))
        elif len(d) == 9 and re.search(r"ssn|social", ctx, re.I):
            sigs.append(("ssn_like", raw))
        elif _CTX.search(ctx):
            sigs.append(("long_number_ctx", raw))
    return sigs


def _luhn(d):
    s, alt = 0, False
    for c in reversed(d):
        n = int(c)
        if alt:
            n = n * 2 - 9 if n > 4 else n * 2
        s += n
        alt = not alt
    return s % 10 == 0


# -------------------------------------------------------------- allow-list
PUBLIC_ALLOWLIST = ["Acme", "Acme Support", "Maya", "support@acme.com", "1-800-555-0199",
                    "18005550199", "help.acme.com"]


def _key(s):
    s = unicodedata.normalize("NFKC", s).lower()
    digits = re.sub(r"\D", "", s)
    return digits if len(digits) >= 6 else re.sub(r"[^a-z0-9@.]", "", s)


def _allowed(span, query):
    k = _key(span)
    if not k:
        return False
    pool = [_key(x) for x in PUBLIC_ALLOWLIST]
    qn = normalize(query or "")
    pool += [_key(query or ""), _key(qn)]
    # token-level containment for names; digit containment for numbers
    for p in pool:
        if k and k in p:
            return True
    return False


# ------------------------------------------------------------------ detector
class Detector:
    def __init__(self, regex=True, ner=True, normalize=False, allowlist=False, tau=30):
        self.regex, self.ner, self.norm, self.allow, self.tau = regex, ner, normalize, allowlist, tau

    def signals(self, text, query=""):
        views = [text]
        if self.norm:
            views.append(normalize(text))
        sigs = []
        for v in views:
            if self.regex:
                for name, pat in PATTERNS:
                    sigs += [(name, m.group(0)) for m in pat.finditer(v)]
                if self.norm:
                    sigs += _digit_run_signals(v)
            if self.ner:
                for ent in _NLP(v).ents:
                    if ent.label_ in ("PERSON", "ORG", "GPE"):
                        sigs.append((f"NER:{ent.label_}", ent.text))
        if self.allow:
            sigs = [s for s in sigs if not _allowed(s[1], query)]
        out = {}
        for n, span in sigs:
            out[(n, span)] = SEV[n]
        return [(n, s, sev) for (n, s), sev in out.items()]

    def score(self, text, query=""):
        s = self.signals(text, query)
        return max([x[2] for x in s], default=0), s

    def predict(self, text, query=""):
        return int(self.score(text, query)[0] >= self.tau)


VARIANTS = {
    "Regex only":            dict(regex=True, ner=False),
    "Regex + NER (original)": dict(regex=True, ner=True),
    "+ Normalization":       dict(regex=True, ner=True, normalize=True),
    "+ Norm. + allow-list":  dict(regex=True, ner=True, normalize=True, allowlist=True),
}
