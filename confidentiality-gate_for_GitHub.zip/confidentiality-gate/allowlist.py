"""Revised allow-list (added in revision, after reviewer comment 5). Detection rules are the
frozen detector.py, unchanged; only the allow-list step is replaced.

Design
  * Source: entities of the authenticated customer's verified account record (name, emails,
    phones, account/order/ticket IDs) plus an operator-maintained public list. The query text
    is NEVER a source, so an attacker cannot whitelist a string by typing it.
  * Matching: per entity, after the detector's normalization key (NFKC, case-folding, digits
    only for numbers); a signal is dropped only if its key equals, or is contained in, the key
    of one record entity. Keys shorter than 3 characters never match.
  * Lifetime: the record is fetched for each request from the system of record and discarded
    after the decision; nothing is cached, so changed or revoked details take effect on the
    next request.
"""
from detector import Detector, PUBLIC_ALLOWLIST, _key


class RecordAllowlistGate:
    def __init__(self, tau=30):
        self.det = Detector(regex=True, ner=True, normalize=True, allowlist=False, tau=tau)
        self.tau = tau

    def signals(self, text, record=()):
        keys = [k for k in (_key(e) for e in list(record) + PUBLIC_ALLOWLIST) if len(k) >= 3]
        out = []
        for name, span, sev in self.det.signals(text):
            k = _key(span)
            if len(k) >= 3 and any(k == rk or k in rk for rk in keys):
                continue
            out.append((name, span, sev))
        return out

    def score(self, text, record=()):
        s = self.signals(text, record)
        return max([x[2] for x in s], default=0), s

    def predict(self, text, record=()):
        return int(self.score(text, record)[0] >= self.tau)
