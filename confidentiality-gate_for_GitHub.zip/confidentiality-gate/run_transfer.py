"""Generator-bias check: apply the D_stress obfuscation operators to identifier spans inside the
independent presidio-research sentences (third-party templates and contexts) instead of the
authors' templates. Only spans the frozen gate catches unobfuscated are used, so any drop is
due to obfuscation. Compares per-operator recall with D_stress."""
import json, hashlib, re, pandas as pd
from detector import Detector, VARIANTS
from synth import OPS
from stats import wilson
assert hashlib.sha256(open('detector.py','rb').read()).hexdigest()==open('results/FROZEN_detector.sha256').read().split()[0]
D=json.load(open('independent/synth_dataset_v2.json'))
MAP={"CREDIT_CARD":"card","US_SSN":"ssn","EMAIL_ADDRESS":"email","PHONE_NUMBER":"phone"}
full=Detector(**VARIANTS["+ Normalization"]); orig=Detector(**VARIANTS["Regex + NER (original)"])
items=[]
for row in D:
    if any(s["entity_type"] in ("PERSON",) for s in row["spans"]): continue   # avoid NER hits masking the test
    for sp in row["spans"]:
        k=MAP.get(sp["entity_type"])
        if not k: continue
        t=row["full_text"]; a,b=sp["start_position"],sp["end_position"]
        others=t[:a]+"X"*(b-a)+t[b:]
        if full.predict(others): continue          # sentence must block only because of this span
        if not full.predict(t): continue           # gate must catch the plain span
        items.append((k,t,a,b,sp["entity_value"]))
rows=[]
for op,(f,kinds) in OPS.items():
    for name,d in [("Regex + NER (original)",orig),("+ Normalization",full)]:
        v=[]
        for k,t,a,b,val in items:
            if k not in kinds: continue
            try: ob=f(val,k)
            except Exception: continue
            if op!='none' and ob==val: continue   # operator had no effect on this value format
            v.append(d.predict(t[:a]+ob+t[b:]))
        if v:
            p,lo,hi=wilson(sum(v),len(v)); rows.append(dict(operator=op,detector=name,n=len(v),recall=p,lo=lo,hi=hi))
df=pd.DataFrame(rows); df.to_csv('results/transfer_results.csv',index=False)
st=pd.read_csv('results/stress_results.csv'); st=st[(st.type=='recall')&(~st.group.str.startswith('kind:'))&(st.group!='ALL')]
m=df[df.detector=="+ Normalization"].merge(st[st.detector=="+ Normalization"][['group','p']],left_on='operator',right_on='group')
m['diff']=m.recall-m.p
print(len(items),"spans; by type:",pd.Series([i[0] for i in items]).value_counts().to_dict())
print(m[['operator','n','recall','p','diff']].round(2).to_string())
allv=df[df.detector=="+ Normalization"]; ao=df[df.detector=="Regex + NER (original)"]
print("pooled transfer recall norm:",round((allv.recall*allv.n).sum()/allv.n.sum(),3),"orig:",round((ao.recall*ao.n).sum()/ao.n.sum(),3),"N=",allv.n.sum())
print("abs diff mean:",round(m['diff'].abs().mean(),3),"max:",round(m['diff'].abs().max(),3))
