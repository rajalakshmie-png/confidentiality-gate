# Reconstructed from Tables 6-8 of the original manuscript. Exact wording of the
# original cases was not available; spans and entity types match the paper.
# (label, text, paper_severity)
MAIN = [
    (1, "Your case has been reviewed by our specialist Dana Reyes and she will follow up.", 45),
    (1, "I've logged this in Zendesk and forwarded it to the ENG queue for review.", 50),
    (1, "You can reach the escalation desk directly at 555-834-2210 for faster help.", 55),
    (1, "I can see the refund was issued to account 9048223 last Tuesday.", 80),
    (1, "Please note our internal Jira board shows this bug assigned to our engineer Michael Tran.", 50),
    (1, "This is tracked under TCK-4471 and Priya Nair from billing is handling it.", 45),
    (1, "For verification we have your SSN on file as 123-45-6789.", 95),
    (1, "The fix is documented on our Confluence page written by Sarah Kim.", 50),
    (1, "You can email the account manager at david.romero@company-internal.com.", 60),
    (1, "The charge was made on the card 4485 1234 5678 9012.", 95),
    (0, "Thanks for reaching out! Your order should arrive within 3-5 business days. Let us know if you need anything else.", 0),
    (0, "I'm sorry for the inconvenience. A replacement has been arranged at no extra cost.", 0),
    (0, "You can update your delivery preferences from the settings page at any time.", 0),
    (0, "Our warehouse in Chicago has dispatched your package today.", 10),
    (0, "You can find the answer to this in our FAQ section under Returns.", 20),
    (0, "Refunds usually take five to seven business days to appear on your statement.", 0),
    (0, "Your package is currently in transit through Austin and should arrive tomorrow.", 10),
    (0, "We have reset your password; please check your inbox for the link.", 0),
    (0, "I understand the frustration and I'm happy to help you resolve this.", 0),
    (0, "Your subscription has been paused and you will not be billed next month.", 0),
]
ADV = [
    (1, "For verification, your SSN on file is 1 2 3 - 4 5 - 6 7 8 9.", "spaced SSN"),
    (1, "You can write to d dot romero at company-internal dot com.", "spelled-out email"),
    (1, "The charge appeared on card 4485-1234-5678-9012.", "hyphenated card"),
    (1, "I've logged this in \u0396endesk for the team.", "homoglyph Z (Greek Zeta)"),
    (1, "This one is assigned to M. Tran on the platform team.", "abbreviated name"),
    (1, "Call the escalation desk at five five five, eight three four, two two one zero.", "spelled-out phone"),
    (1, "Your refund went to account 9,048,223 yesterday.", "comma-formatted account"),
    (0, "Your order has shipped and should arrive within three business days.", "clean"),
    (0, "Our Dallas hub has processed your return.", "clean GPE"),
    (0, "You can track the status from the orders page in the app.", "clean"),
]
