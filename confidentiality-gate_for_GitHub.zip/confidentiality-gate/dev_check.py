from detector import Detector, VARIANTS
from data_dev import DEV
for name,cfg in VARIANTS.items():
    d=Detector(**cfg); tp=fn=fp=tn=0; errs=[]
    for y,cat,sub,q,r in DEV:
        s,sig=d.score(r,q); p=int(s>=30)
        tp+=y&p; fn+=y&(1-p); fp+=(1-y)&p; tn+=(1-y)&(1-p)
        if p!=y: errs.append((sub,s,[(a,b) for a,b,_ in sig][:3]))
    print(f"== {name}: TP{tp} FN{fn} FP{fp} TN{tn}")
    for e in errs: print("   ",e)
