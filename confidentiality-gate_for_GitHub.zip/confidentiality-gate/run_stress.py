import csv, time, json
from collections import defaultdict
from detector import Detector, VARIANTS
from presidio_det import PresidioDetector
from synth import leak_cases, benign_cases
from stats import wilson
L=leak_cases(100); B=benign_cases(100)
dets={"Presidio (default)":PresidioDetector(0.3), **{k:Detector(**v) for k,v in VARIANTS.items() if k!="+ Norm. + allow-list"}}
hits=defaultdict(lambda: defaultdict(list)); fps=defaultdict(lambda: defaultdict(list)); lat=defaultdict(list)
for name,d in dets.items():
    for op,kind,t in L:
        t0=time.perf_counter(); p=d.predict(t); lat[name].append((time.perf_counter()-t0)*1000)
        hits[name][op].append(p); hits[name][f"kind:{kind}"].append(p)
    for cat,t in B:
        fps[name][cat].append(d.predict(t))
out=[]
for name in dets:
    for op,v in hits[name].items():
        k,n=sum(v),len(v); p,lo,hi=wilson(k,n); out.append(dict(detector=name,group=op,type="recall",k=k,n=n,p=p,lo=lo,hi=hi))
    for cat,v in fps[name].items():
        k,n=sum(v),len(v); p,lo,hi=wilson(k,n); out.append(dict(detector=name,group=cat,type="false_positive",k=k,n=n,p=p,lo=lo,hi=hi))
    allv=[x for op,v in hits[name].items() if not op.startswith("kind:") for x in v]
    p,lo,hi=wilson(sum(allv),len(allv)); out.append(dict(detector=name,group="ALL",type="recall",k=sum(allv),n=len(allv),p=p,lo=lo,hi=hi))
    allb=[x for v in fps[name].values() for x in v]
    p,lo,hi=wilson(sum(allb),len(allb)); out.append(dict(detector=name,group="ALL",type="false_positive",k=sum(allb),n=len(allb),p=p,lo=lo,hi=hi))
with open('results/stress_results.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=out[0].keys()); w.writeheader(); w.writerows(out)
json.dump({k:v for k,v in lat.items()},open('results/stress_latency_ms.json','w'))
for r in out:
    if r['type']=='recall' and not r['group'].startswith('kind:') or r['group']=='ALL' or r['type']=='false_positive':
        pass
import pandas as pd
df=pd.DataFrame(out)
print(df[df.type=='recall'].pivot(index='group',columns='detector',values='p').round(2).to_string())
print(df[df.type=='false_positive'].pivot(index='group',columns='detector',values='p').round(3).to_string())
