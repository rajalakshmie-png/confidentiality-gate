import csv
from detector import Detector, VARIANTS
from data_dev import DEV
rows=[]
for name,cfg in VARIANTS.items():
    d=Detector(**cfg)
    scores=[(y,d.score(r,q)[0]) for y,c,s,q,r in DEV]
    for tau in range(5,101,5):
        tp=sum(1 for y,s in scores if y and s>=tau); fn=sum(1 for y,s in scores if y and s<tau)
        fp=sum(1 for y,s in scores if not y and s>=tau); tn=sum(1 for y,s in scores if not y and s<tau)
        rows.append(dict(variant=name,tau=tau,tp=tp,fn=fn,fp=fp,tn=tn,acc=(tp+tn)/len(scores)))
with open('results/dev_calibration.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows:
    if r['variant'].startswith('+ Norm. +'): print(r['tau'],r['tp'],r['fn'],r['fp'],r['tn'],round(r['acc'],3))
